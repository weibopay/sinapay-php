<?php
//测试sdk文件
header("Content-type: text/html; charset=utf-8");
include_once ("../config/conf.php");
include_once ("../api/sinaSDK.php");
setPayPassword();
	
	function queryBankCard()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_bank_card";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["card_id"]="";
		$sParaTemp["request_time"]="20190408180129";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["return_url"]="http://www.xxx.com/query_bank_card.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function setPayPassword()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="set_pay_password";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["withhold_param"]="withhold_auth_type^ALL,ACCOUNT|is_check^Y";
		$sParaTemp["request_time"]="20190409101214";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["return_url"]="http://www.xxx.com/pay_password.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function modifyPayPassword()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="modify_pay_password";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["withhold_param"]="";
		$sParaTemp["request_time"]="20190409103152";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["return_url"]="http://www.xxx.com/pay_password.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function findPayPassword()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="find_pay_password";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["withhold_param"]="";
		$sParaTemp["request_time"]="20190409103221";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["return_url"]="http://www.xxx.com/pay_password.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function queryIsSetPayPassword()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_is_set_pay_password";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["withhold_param"]="";
		$sParaTemp["request_time"]="20190409103246";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["return_url"]="http://www.xxx.com/pay_password.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function bindingBankCardAdvance()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="binding_bank_card_advance";
		$sParaTemp["ticket"]="xxxxxxxxxxxxxxxxxxxxxxx";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409103310";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["valid_code"]="020202";
		$sParaTemp["return_url"]="http://www.xxx.com/binding_bank_card_advance.html";
		$sParaTemp["client_ip"]="101.231.34.38";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function unbindingBankCard()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="unbinding_bank_card";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["card_id"]="397880";
		$sParaTemp["request_time"]="20190409103402";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["advance_flag"]="Y";
		$sParaTemp["return_url"]="http://www.xxx.com/unbinding_bank_card.html";
		$sParaTemp["client_ip"]="101.231.34.38";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function unbindingBankCardAdvance()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="unbinding_bank_card_advance";
		$sParaTemp["ticket"]="324e3bfecb3b4ffb94c9000bf73021ba";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409103417";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["valid_code"]="020202";
		$sParaTemp["return_url"]="http://www.xxx.com/unbinding_bank_card_advance.html";
		$sParaTemp["client_ip"]="101.231.34.38";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	
	function queryBalance()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_balance";
		$sParaTemp["account_type"]="SAVING_POT";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409103541";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["return_url"]="http://www.xxx.com/query_balance.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function queryAccountDetails()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_account_details";
		$sParaTemp["account_type"]="SAVING_POT";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["end_time"]="20190409103607";
		$sParaTemp["memo"]="";
		$sParaTemp["page_no"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["start_time"]="20190409103607";
		$sParaTemp["request_time"]="20190409103607";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["return_url"]="http://www.xxx.com/query_account_details.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sParaTemp["extend_param"]="";
		$sParaTemp["page_size"]="";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function balanceFreeze()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="balance_freeze";
		$sParaTemp["summary"]="非法占用";
		$sParaTemp["account_type"]="SAVING_POT";
		$sParaTemp["amount"]="2";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409103635";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["return_url"]="http://www.xxx.com/balance_freeze.html";
		$sParaTemp["out_freeze_no"]="freeze20190409103634";
		$sParaTemp["client_ip"]="101.231.34.38";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function balanceUnfreeze()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="balance_unfreeze";
		$sParaTemp["out_unfreeze_no"]="unfreeze20190409103817";
		$sParaTemp["summary"]="事件已处理";
		$sParaTemp["amount"]="2";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409103818";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["return_url"]="http://www.xxx.com/balance_unfreeze.html";
		$sParaTemp["out_freeze_no"]="freeze20190409103634";
		$sParaTemp["client_ip"]="101.231.34.38";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function queryCtrlResult()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_ctrl_result";
		$sParaTemp["request_time"]="20190409103937";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["out_ctrl_no"]="freeze20190409103634";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["return_url"]="http://www.xxx.com/query_ctrl_result.html";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function queryMemberInfos()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_member_infos";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409104002";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["is_mask"]="N";
		$sParaTemp["return_url"]="http://www.xxx.com/query_member_infos.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function queryAuditResult()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_audit_result";
		$sParaTemp["request_time"]="20190409104029";
		$sParaTemp["partner_id"]="200004595271";
		$sParaTemp["identity_id"]="20180625172348";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["return_url"]="http://www.xxx.com/query_audit_result.html";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["version"]="1.2";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function auditMemberInfos()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="audit_member_infos";
		$sParaTemp["member_type"]="2";
		$sParaTemp["bank_branch"]="中国工商银行深圳南山支行";
		$sParaTemp["cert_type"]="IC";
		$sParaTemp["fileName"]="20190409104807.zip";
		$sParaTemp["license_address"]="上海";
		$sParaTemp["city"]="上海市";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["cert_effect_date"]="20151002";
		$sParaTemp["cert_invalid_date"]="forever";
		$sParaTemp["memo"]="";
		$sParaTemp["card_attribute"]="B";
		$sParaTemp["legal_person_phone"]="18956236585";
		$sParaTemp["license_no"]="20000000000002";
		$sParaTemp["request_time"]="20190409104642";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["province"]="上海市";
		$sParaTemp["digest"]="29880fa0c06ac9df31059d8e84d252a4";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["client_ip"]="101.231.34.38";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sParaTemp["organization_no"]="200010000009";
		$sParaTemp["extend_param"]="";
		$sParaTemp["email"]="ms@weibopay.com";
		$sParaTemp["summary"]="企业简介";
		$sParaTemp["bank_code"]="ICBC";
		$sParaTemp["website"]="sssss";
		$sParaTemp["legal_person"]="李某某";
		$sParaTemp["address"]="测试公司的企业地址";
		$sParaTemp["cert_no"]="140428200105314950";
		$sParaTemp["identity_id"]="20190409104630";
		$sParaTemp["digestType"]="MD5";
		$sParaTemp["bank_account_no"]="6212264100011335373";
		$sParaTemp["license_expire_date"]="20201002";
		$sParaTemp["telephone"]="4009218887";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["card_type"]="DEBIT";
		$sParaTemp["version"]="1.2";
		$sParaTemp["audit_order_no"]="audit_member20190409104642";
		$sParaTemp["business_scope"]="软件开发，软件测试，金融";
		$sParaTemp["company_name"]="测试公司的全称";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function changeBankMobile()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="change_bank_mobile";
		$sParaTemp["phone_no"]="18796265852";
		$sParaTemp["identity_id"]="20190409104630";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["request_no"]="bilbancart20190409104856";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["card_id"]="152369";
		$sParaTemp["request_time"]="20190409104856";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function changeBankMobileAdvance()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="change_bank_mobile_advance";
		$sParaTemp["request_time"]="20190409104934";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["valid_code"]="026302";
		$sParaTemp["ticket"]="8dijfj855g855fg";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function smtFundAgentBuy()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="smt_fund_agent_buy";
		$sParaTemp["agent_name"]="夏黎珊";
		$sParaTemp["identity_id"]="20190409104630";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["agent_mobile"]="15695263254";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["license_type_code"]="ID";
		$sParaTemp["license_no"]="330100199910163443";
		$sParaTemp["request_time"]="20190409105007";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["client_ip"]="101.231.34.38";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sParaTemp["email"]="45885@qq.com";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function queryFundAgentBuy()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_fund_agent_buy";
		$sParaTemp["identity_id"]="20190409104630";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409105354";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sParaTemp["extend_param"]="";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function modifyVerifyMobile()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="modify_verify_mobile";
		$sParaTemp["request_time"]="20190409105457";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["identity_id"]="20190409104630";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["version"]="1.2";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function findVerifyMobile()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="find_verify_mobile";
		$sParaTemp["request_time"]="20190409105457";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["identity_id"]="20190409104630";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["version"]="1.2";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function handleWithholdAuthority()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="handle_withhold_authority";
		$sParaTemp["identity_id"]="20190409104630";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["auth_type_whitelist"]="ALL,ACCOUNT";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409105555";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["quota"]="2000";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sParaTemp["extend_param"]="";
		$sParaTemp["day_quota"]="4000";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function modifyWithholdAuthority()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="modify_withhold_authority";
		$sParaTemp["identity_id"]="20190409104630";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409105623";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["quota"]="3000";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sParaTemp["day_quota"]="3800";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function queryWithholdAuthority()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_withhold_authority";
		$sParaTemp["auth_type"]="ALL";
		$sParaTemp["identity_id"]="20190409104630";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409105654";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["is_detail_disp"]="Y";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function queryFundYield()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_fund_yield";
		$sParaTemp["request_time"]="20190409105724";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["sign_type"]="RSA";
		$sParaTemp["fund_code"]="000330";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function setMerchantConfig()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="set_merchant_config";
		$sParaTemp["config_value"]="MEMBER_INFO_GENERAL_NOTIFY_URL";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409105820";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["config_key"]="MEMBER_INFO_GENERAL_NOTIFY_URL";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["sign_type"]="RSA";
		$sParaTemp["extend_param"]="";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function queryMerchantConfig()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="query_merchant_config";
		$sParaTemp["request_time"]="20190409110034";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["config_key"]="MEMBER_INFO_GENERAL_NOTIFY_URL";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function merchantReport()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="merchant_report";
		$sParaTemp["contact_name"]="sss";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["merchant_name"]="sss";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["mcc"]="";
		$sParaTemp["version"]="1.2";
		$sParaTemp["contact_identity"]="02";
		$sParaTemp["custom_telephone"]="0102523685";
		$sParaTemp["contact_type"]="LEGAL_PERSON";
		$sParaTemp["request_time"]="20190409110225";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["merchant_identitiy_type"]="UID";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["merchant_identity_id"]="20181012100627";
		$sParaTemp["short_name"]="ss";
		$sParaTemp["report_org"]="TENPAY";
		$sParaTemp["client_ip"]="127.0.0.1";
		$sParaTemp["sign_type"]="RSA";
		$sParaTemp["app_id"]="sssssssssssssw";
		$sParaTemp["extend_param"]="";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}
	
	function smerchantUrlGet()
	{
		$sinaSDK = new sinaSDK();
		$sParaTemp["service"]="smerchant_url_get";
		$sParaTemp["member_type"]="1";
		$sParaTemp["identity_id"]="20190409110740";
		$sParaTemp["_input_charset"]="utf-8";
		$sParaTemp["cashdesk_addr_category"]="";
		$sParaTemp["memo"]="";
		$sParaTemp["notify_url"]="http://10.65.106.83:8080/java_demo_zhanghu/Notify";
		$sParaTemp["version"]="1.2";
		$sParaTemp["request_time"]="20190409110740";
		$sParaTemp["partner_id"]="20000918888";
		$sParaTemp["return_url"]="http://www.xxx.com/index.html";
		$sParaTemp["client_ip"]="101.231.34.38";
		$sParaTemp["identity_type"]="UID";
		$sParaTemp["sign_type"]="RSA";
		$sinaSDK_result = $sinaSDK -> mgs_sdk($sParaTemp);
		print_r($sinaSDK_result);
	}



?>